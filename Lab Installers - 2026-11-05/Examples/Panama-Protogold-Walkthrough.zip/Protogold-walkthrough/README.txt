SYNTHETIC TRAINING PAIR - not reconstructed experimental evidence.

The Western and Protogold TIFFs share known imposed migration shifts.
Open 01-before-alignment.panama to inspect and apply the eight protein landmarks.
Open 02-aligned-and-measured.panama for the completed example, including all five analyses.
In Images & lanes click Protogold beside Western to switch scans.
Protogold supplies position landmarks. Western baseline is a separate constant 0.06
(normalized units), equivalent to 15.3 on the 0-255 signal scale.
Use Measurements > Mean signal (0-255), or the same Measure option in Analysis.
The supplied Excel workbook records those measurements.

These are the controlled 18-sample fixtures from Test-pack/02-warped-groups.
Maximum area error vs analytic truth: 0.390%; protein correlation after alignment: 0.999.
No missing Protogold scan from Vale et al. has been inferred or manufactured as real data.
